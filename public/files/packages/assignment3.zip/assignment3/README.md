# Assignment 3：DDPM 与 DDIM

在 GPU 环境中打开 `DDPM_DDIM.ipynb`，按顺序运行并完成其中的 TODO。
作业要求、截止时间和提交方式以课程网站 Assignment-3 页面为准。
本地运行可安装 `requirements.txt`；使用 Colab 时，先启用 GPU 运行时。

本作业改编自 KAIST CS492(C) Fall 2025 Programming Assignment 1：
https://github.com/KAIST-Visual-AI-Group/Diffusion-2025-Assignment1-DDPM-DDIM
原作者信息保留在 notebook 开头。
